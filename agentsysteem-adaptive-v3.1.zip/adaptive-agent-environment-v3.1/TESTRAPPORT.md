# Testrapport - Adaptive Agent Environment v3.1.0

Datum: 29 september 2026. Uitgevoerd op tijdelijke lokale projecten met Linux en Node v22.16.0. Het echte Takenlijstje-project, een live Supabase-database en het eerder geinstalleerde v3-project zijn hierbij niet gewijzigd.

## Resultaat

**134 geautomatiseerde tests uitgevoerd: 134 geslaagd, 0 mislukt, 0 overgeslagen.** De laatste volledige run duurde ongeveer 2,8 seconde in deze omgeving. Dit is lokale testduur, geen schatting van Claude-modelverbruik of Max-tegoed.

De v3-basistests blijven aanwezig. V3.1 voegt daar gerichte tests voor externe integraties aan toe: Supabase-projectbinding per gebruikersvraag, read-only toolclassificatie, veilige SQL-classificatie, migratie-GO, aparte gevoelige toestemming, extern budget, gesaniteerde receipts, foutafhandeling zonder automatische reparatie-agents en routegebonden GitHub PR-aanmaak.

| Onderdeel | Belangrijkste dekking |
|---|---|
| Route/poort | analyse versus implementatie, oningevulde templates, actuele toestemming, bron-/scopegrenzen, pauze/hervatten |
| Agents/lifecycle | alleen geplande agents, budget, foreground/lifecycle, geen MCP voor subagents |
| Commandrunner/bewijs | bounded argv, commandreceipts, bronversie, timeout/failure, geen vrije shellomweg |
| Supabase v3.1 | bounded `get_project_url`-probe, projectbinding per huidige vraag, expliciete toolallowlist, read-only SQL, `apply_migration`, sensitive GO, budget, receipts zonder raw resultaten |
| GitHub v3.1 | alleen `create_pull_request`, exacte base/head, actuele GO; merge blijft buiten adapter |
| Installer/update | dry-run, backup/rollback, behoud appcode/projectregels, v3 -> v3.1 beheerde update, lopende externe call blokkeert update |
| Config/docs | 13 bestaande agents, geen nieuwe agentrol, Node-syntaxis, manifesthashes, voorbeelden en documentlinks |

Reproduceren vanuit de uitgepakte pakketmap:

```sh
node tools/test.mjs
```

Dit start geen Claude-agent, externe API, browser of Supabase/GitHub-call. Tests gebruiken tijdelijke fixtures en gesimuleerde hook-events.

## V3 -> v3.1 upgradeproef

Naast de testsuite is een volledig v3-pakket in een tijdelijk project geinstalleerd, is v3-lokale state aangemaakt en is daarna de v3.1-installer eerst als plan en vervolgens met `--apply` uitgevoerd.

Gecontroleerd:
- updateplan had **0 conflicten**;
- installer rapporteerde **INSTALLED**;
- beheerde pakketversie werd **3.1.0**;
- eigen projectregel in `CLAUDE.md` bleef behouden;
- een appcode-controlebestand bleef byte-voor-byte gelijk;
- de v3-lokale state kon blijven bestaan en v3.1 `doctor` werkte;
- PostToolUse/PostToolUseFailure zijn breed genoeg geconfigureerd om externe lifecycle-receipts te zien;
- herstelkopie werd gemaakt.

Het reproduceerbare resultaat staat in `evidence/v3-to-v31-upgrade.json`; de laatste volledige testuitvoer in `evidence/node-tests-v31.tap`.

## Belangrijke v3.1 veiligheidsgevallen

De integratietests bevestigen onder andere:
- projectverificatie wordt niet stil tussen verschillende gebruikersvragen hergebruikt;
- `apply_migration` faalt gesloten als naam of SQL ontbreekt;
- muterende `execute_sql` loopt niet als gewone read-route;
- gevoelige/destructieve SQL vereist exact geplande inhoud plus `AAE GEVOELIG GO <taak-id>`;
- onbekende Supabase-tools blijven standaard geblokkeerd;
- GitHub PR-aanmaak vereist expliciete, overeenkomende base/head;
- externe calls verbruiken hun eigen budget en geen agentbudget;
- toolresponses worden niet rauw in receipts opgeslagen.

## Wat is nadrukkelijk niet getest?

**De echte Claude Code-host van de gebruiker: NOT_RUN in deze buildomgeving.** Hook-events zijn via echte Nodeprocessen getest maar de Anthropic-host zelf draait hier niet.

**De echte Supabase-connector van Takenlijstje: NOT_RUN.** Er is geen productieproject gebonden en geen echte query/migratie uitgevoerd. De eerste hostcontrole hoort read-only te zijn (`get_project_url` + `list_migrations`) zoals beschreven in `.claude/aae/docs/LIVE_CHECK.md`.

**Productiedatabase-mutaties: NOT_RUN.** Geen migratie, cron, Vault-secret, RLS of datawijziging is uitgevoerd.

**Echte GitHub PR-tool via AAE: NOT_RUN in Claude Code.** Toolclassificatie en routebinding zijn lokaal getest; een eventuele live proef hoort alleen in een wegwerprepo.

**Windows/macOS/cloudhost: NOT_RUN.** Lokale tests zijn op Linux uitgevoerd. Hostpermissions en toolnamen moeten door de korte live-check bevestigd worden.

**Abonnementsbesparing: NIET GEMETEN.** Agent- en externe budgetten zijn gescheiden en afgedwongen, maar er wordt geen besparingspercentage beloofd.

**Volledige OS-sandbox: NIET GELEVERD.** AAE bewaakt de ondersteunde workflow; door jou goedgekeurde projectcode blijft onder jouw normale hostrechten draaien.

## Vrijgaveadvies

Het pakket is lokaal groen en de v3 -> v3.1 update is in een tijdelijk project doorlopen. Installeer v3.1 eerst op een aparte branch, start daarna een verse Claude Code-sessie en voer `doctor` plus de read-only Supabase-livecheck uit. Gebruik pas daarna de adapter voor de echte WP3-migraties. Als de werkelijke Supabase-toolnamen afwijken van de expliciete allowlist, pas alleen die classificatie gericht aan; maak geen wildcard voor alle MCP-tools.
