# 3.1.0 - 2026-09-29
- Voegt een smalle Supabase-adapter toe met projectbinding, read-only controles, `apply_migration`, apart extern budget en gesaniteerde receipts.
- Blokkeert onbekende Supabase-tools; muterende `execute_sql` is geen normale route. Gevoelige/destructieve acties vereisen exact geplande scope plus `AAE GEVOELIG GO`.
- Voegt gecontroleerde GitHub `create_pull_request` toe; merge/deploy blijven buiten de adapter.
- Staat `ToolSearch` toe voor de hoofdsessie zodat beschikbare externe tools ontdekt kunnen worden; subagents blijven zonder MCP.
- Bekende niet-destructieve migraties kunnen Standard blijven; migratie-, rollback- en data-preservationbewijs blijven verplicht.
- Externe toolcalls krijgen een eigen budget en worden meegenomen in update-/lifecyclebewaking.
- Geen nieuwe agents; bestaande 13 rollen blijven ongewijzigd behalve routingadvies.

# 3.0.0 - 2026-09-29
- Vervangt markdownbeslissingen en oude niveauvrijgave door gevalideerde taakcontracten.
- Voegt taskgebonden GO/pauze, agentbudget, dispatchregistratie en bounded commandrunner toe.
- Scherpt 13 rollen aan; alle specialistische uitvoer read-only, model/maxTurns expliciet.
- Scheidt analyse, implementatie, beoordeling en deployment; geen automatische publicatie.
- Voeg veilige dry-run-installer, gecontroleerde v1/v2-retirement, backup/rollback en doctor toe.
- Voegt onafhankelijke/actuele bewijsvoorwaarden, gerichte visuele fixturehelper en live-check toe.
- Houdt OS-sandbox, hostcompatibiliteit en abonnementsmeting expliciet buiten onbewezen claims.

Zie TESTRAPPORT.md voor daadwerkelijk uitgevoerde controles. Geen live app-/Claude-/Max-meting in deze build.
