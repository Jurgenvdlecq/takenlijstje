# Adaptive Agent Environment v3.1.0
## Minder overbodig werk, aantoonbare kwaliteit

Dit is de v3.1-upgrade van de agentomgeving op basis van de v2-audit. Het is een **installatiepakket**, niet een map die je blind over je project uitpakt. De applicatie Takenlijstje is niet gewijzigd. Er staan geen wachtwoorden, API-sleutels of persoonlijke projectgegevens in dit pakket.

### Wat is veranderd sinds v3?
V3.1 voegt twee smalle externe adapters toe zonder nieuwe agentrollen: Supabase database/migraties en GitHub pull-request aanmaken. Bekende read-only Supabase-checks kunnen binnen een route rechtstreeks door de hoofdsessie; `apply_migration` en PR-aanmaak zijn routegebonden wijzigingen. Onbekende MCP-tools, GitHub merge-acties en secrets blijven geblokkeerd. Externe calls krijgen een eigen budget/receipts en tellen niet als agentcalls. Een gewone bekende niet-destructieve migratie forceert niet langer automatisch High Assurance, maar de migratiebewijzen blijven verplicht.

### Bestaande v3-principes blijven behouden
De 13 rollen blijven beschikbaar. Een kleine taak kan de hoofdsessie zelf routeren; een onduidelijke of risicovolle taak krijgt een lichte supervisor. Geselecteerde specialisten krijgen een concrete vraag en uitsluitend leesrechten. De hoofdsessie bouwt, voert gecontroleerde commands uit en verwerkt de resultaten.

Een gevalideerd taakcontract bewaakt fase, toegestane agents, bronpaden, budget en toestemming. Oude GO's gelden niet voor een andere opdracht. Budget blijft tellen bij hervatten; een template geeft nooit bouwtoestemming. Nieuwe commandoversies worden niet stil vertrouwd. Bewijs is gekoppeld aan de route en de relevante bronversie.

Dit is geen volledige OS-sandbox en geen meter voor Claude Max-tegoed. De ingebouwde checks zijn lokaal getest; een echte Claude Code-sessie, browserflow, jouw app en abonnementsverbruik zijn hier niet uitgevoerd of gemeten. Zie TESTRAPPORT.md en de live-check.

### Zo installeer je veilig
1. Stop lopende Claude Code-agents en sluit de bestaande sessie. Maak bij voorkeur een normale projectbackup/Git-commit; de installer heeft daarnaast zijn eigen herstelkopie.
2. Pak deze ZIP uit in een aparte map, **buiten je project**. Laat de map `payload` intact. Open een normale terminal in de uitgepakte map `adaptive-agent-environment-v3.1`.
3. Maak eerst alleen het installatieplan (vervang het pad):

```sh
node install.mjs --project "/pad/naar/takenlijstje"
```

Dit schrijft nog niets in de projectmap. Bij `conflicts` stopt de installatie; niets blind overschrijven. Bestaande appcode, projectinstructies, permissies en overige hooks blijven behouden. Exact herkende oude agentbestanden worden apart gearchiveerd; aangepaste oude bestanden vragen een bewuste samenvoeging.

4. Klopt het plan, voer dezelfde opdracht uit met `--apply`:

```sh
node install.mjs --project "/pad/naar/takenlijstje" --apply
```

Bewaar het teruggegeven `backup`-pad. De installer start geen agents, tests, appwijzigingen, Git-commits of deployment.

5. Start een nieuwe Claude Code-sessie in je project. Controleer `/hooks` en `/agents`: de rollen beginnen met `aae-`; er komen geen nieuwe agents bij. Laat uitsluitend `node .claude/aae/runtime/cli.mjs doctor` draaien. Verander de app nog niet. Een automatische bevestiging in tekst is geen bewijs dat hooks geladen zijn.
6. Doe eerst de korte proef uit `.claude/aae/docs/LIVE_CHECK.md` in een wegwerpkopie. Ga pas daarna met normale appwijzigingen verder.

### Geen terminal beschikbaar?
Gebruik INSTALLATIEPROMPT.txt als begeleide opdracht aan Claude Code. Als bestaande bescherming installatie blokkeert: niet uitschakelen of omzeilen. Laat Claude aangeven welke handmatige stap in een normale terminal nodig is. De nieuwe omgeving kan zichzelf bewust niet vrij overschrijven tijdens appwerk.

### Daarna gewoon opdrachten geven
Bijvoorbeeld: "Maak het Vandaag-scherm eenvoudiger. Geef eerst een voorstel en bouw nog niets."

Claude kiest de passende route. Alleen wanneer werkelijk nodig vraagt hij `AAE GO`. Na een afgesproken route werkt hij zelfstandig verder. `AAE PAUZE` trekt toestemming in, `AAE VERDER` hervat dezelfde taak zonder budgetreset. Een nieuwe projectcommand kun je na bewuste beoordeling herbruikbaar maken met `AAE VERTROUW`; dat geldt niet voor publiceren, installeren of destructieve acties.

### Belangrijke gebruiksgrens
Deze versie ondersteunt de gebruikelijke ingebouwde lees-/schrijftools, gecontroleerde shelluitvoering, de read-only agents en twee gerichte externe adapters. Supabase: alleen de expliciet gedocumenteerde database/read/migratietools. GitHub: alleen `create_pull_request`. Alle andere MCP-/pluginacties, agentteams en skills blijven standaard geblokkeerd. Zie `.claude/aae/docs/INTEGRATIONS.md`.

### Vereisten en eerlijkheid
Node 20 of nieuwer. Conservatieve Claude Code-doelversie: 2.1.246 of nieuwer, gebaseerd op de geraadpleegde documentatie, niet op een live hosttest. Lokaal getest met Node 22.16.0 op Linux. Windows/Git Bash/WSL/cloud-hosts moeten hun eigen live-check doorlopen. Native Windows `.cmd`-commands worden niet stil via een shell uitgevoerd; gebruik daar een echte executable/Node-entrypoint of een expliciet beoordeelde wrapper, of WSL. Geen automatische software-installatie.

Lees voor details `.claude/aae/docs/INSTALLATION.md` onder `payload`. Het auditoverzicht staat in AUDIT_NAAR_V3.md. Dit is een zelfstandig projectpakket, geen officieel Anthropic-product.
