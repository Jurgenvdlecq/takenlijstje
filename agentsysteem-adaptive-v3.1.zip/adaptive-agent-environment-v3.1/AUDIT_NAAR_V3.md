> **V3.1-notitie:** dit document beschrijft de audit die tot v3 leidde. V3.1 is een gerichte vervolgupgrade voor Supabase- en PR-integraties; de v3-auditprincipes blijven gelden. Zie TESTRAPPORT.md en payload/.claude/aae/docs/INTEGRATIONS.md.

# Van audit naar v3 - wat is wel en niet geleverd

De v2-audit is als probleemlijst gebruikt. Er is geen generieke belofte dat elke workflow onder alle hosts onfeilbaar is. Testnamen in de meegeleverde suites koppelen belangrijke negatieve gevallen aan A01-A24. Hieronder staan implementatie en restgrens.

| Punt | Implementatie in v3 | Restgrens |
|---|---|---|
| C1 Agentselectie/budget | PreToolUse Agent/Task, allowlist, reserveringen, totale taskcalls, slots, lifecycle | Host moet hooks correct uitvoeren; SubagentStart alleen is geen blokkeerhaak |
| C2 Template/analyse | Strikt JSON, expliciete fase, lege analyse-schrijfscope, geen markdownautoriteit | Intentie in natuurlijke taal blijft oordeel van het model |
| C3 Oude GO | Taak-ID, routehash, requestbinding, pauzestatus, counters behouden | Externe eigenaar kan lokale bestanden wijzigen; geen adversariële sandbox |
| C4 Schrijfrechten | Specialisten read-only; directe paden incl symlinks; alleen vaste shellrunner; argv zonder shell | Goedgekeurde projectcommands kunnen neveneffecten hebben; geen volledige transitive code-analyse |
| C5 Verbruik | Expliciet model/maxTurns, max_calls, max_runs, totaalbudget, foutlimiet, compacte output | Geen harde Max-/eurogrens; hoofdsessiedenken niet te limiteren met dit pakket |
| C6 Bewijs | Risico-afhankelijke minimumchecks; bron/route-receipts; high-assurance onafhankelijk oordeel; PARTIAL/BLOCKED | Bewijsinhoud niet automatisch bewezen; echte CLI-check nog NOT_RUN |
| C7 Installatie | Dryrun, hashes, bekende oude files archiveren, settingsmerge, conflicts, backup/rollback | User/managed/pluginlagen blijven afzonderlijk te controleren |
| O1 Lichte router | Hoofdsessie mag kleine duidelijke opdracht zonder model-supervisor doen | Routerkwaliteit vraagt live evaluatie |
| O2 Werkpakket | Vraag, relevante files, criteria, gewenste uitvoer, stopcriterium bij dispatch | Volledige semantische context kan niet automatisch worden afgedwongen |
| O3 Rapportage | Gemeenschappelijk bewijs/niet-getest/onzekerheid en READY/PARTIAL/BLOCKED | Positief oordeel is geen gebruikers-GO of deploymentbewijs |
| O4 Testontwerp | Test-writer krijgt gedragsregels, vraagt regressietest oude/nieuwe situatie | Specialist schrijft voorstel; hoofdsessie implementeert en voert uit |
| O5 Testkosten | Runtime/output/risk leidend; brede snelle suite niet verboden | Geen fictieve besparingscijfers |
| O6 Visueel | Optionele fixturehelper met storageState, expected URL/marker, metadata | Browsers/fixtures niet meegeleverd; browserruntime niet getest |
| O7 Basiskwaliteit | Baseline hoofdwerker, risicochecks zonder altijd specialist | Geen compliancecertificaat |
| O8 Herstel | Persistente counters, onbekende slots blokkeren, handmatige recovery, failretrygrens | HERSTEL stopt geen OS-proces; echte cancellation via host |
| O9 Minder verplichtingen | Geen vaste plan-critic/docstraat; JSON alleen relevante checks | Basisscope/bewijsadministratie blijft bewust verplicht voor projectwerk |
| O10 Onderhoud | Doelversie, doctor, UTF-8, installer, manifest, lokale tests | Andere OS/CLI-versies niet als getest gepresenteerd |

## Niet gebouwd
Geen nieuwe specialistleger-uitbreiding, geen cloudtelemetrie, geen metering-dashboard, geen generiek agentframework voor elke provider, geen automatisch lokaal pakketbeheer, geen automatische migraties/deployments en geen automatische algemene audits. Geen gedeelde live state tussen meerdere werkmappen. Een werkmap heeft een actieve hoofdsessie; andere sessies nemen alleen expliciet over.

## Ontwerpkeuze
Specialisten leveren expertise en onafhankelijk oordeel zonder schrijfrechten. De hoofdsessie bouwt en voert de afgestemde tests uit. Hierdoor vervalt een groot deel van de v2-shellrollencomplexiteit. Minder flexibiliteit voor willekeurige tools is een bewuste grens, geen garantie dat alle mogelijke applicaties zonder projectconfiguratie werken.
