#!/usr/bin/env node
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {planInstall,publicPlan,applyInstall,rollback} from './tools/install-core.mjs';
const root=path.dirname(fileURLToPath(import.meta.url));
try {
  if(Number(process.versions.node.split('.')[0])<20)throw new Error('Node 20 of nieuwer vereist.');
  const args=process.argv.slice(2),options={apply:false};
  for(let i=0;i<args.length;i++) {
    const k=args[i];
    if(k==='--apply')options.apply=true;
    else if(['--project','--rollback','--resolved-claude'].includes(k)){if(!args[i+1]||args[i+1].startsWith('--'))throw new Error('Waarde ontbreekt bij '+k);options[k.slice(2)]=args[++i];}
    else throw new Error('Onbekend argument: '+k);
  }
  if(!options.project)throw new Error('Gebruik: node install.mjs --project /pad/naar/project [--apply]. Zonder --apply alleen een plan.');
  let out;
  if(options.rollback)out=rollback(path.resolve(options.project),options.rollback,{apply:options.apply});
  else {const p=planInstall(root,path.resolve(options.project),{resolvedClaude:options['resolved-claude']||null});out=options.apply?applyInstall(p):publicPlan(p);if(p.conflicts.length)process.exitCode=2;}
  console.log(JSON.stringify(out,null,2));
} catch(e){console.error('AAE INSTALLER: '+e.message);process.exitCode=2;}
