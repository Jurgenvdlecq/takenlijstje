/** Transactional, local-only installer. No app code, network, or git operations. */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const fail=(b,m)=>{if(!b)throw new Error(m);};
const BLOCK='<!-- AAE V3 MANAGED START -->\n@.claude/aae/ENTRY.md\n<!-- AAE V3 MANAGED END -->';
const IGNORE='# AAE V3 LOCAL START\n/.claude/aae/state/\n/.claude/aae/private/\n/.aae-backups/\n/docs/aae/TASK.json\n/docs/aae/RESULT.json\n/docs/aae/evidence/\n/docs/aae/notes/\n# AAE V3 LOCAL END';
export function safe(root,rel) {
  fail(typeof rel==='string'&&!rel.startsWith('/')&&!/[\\:\x00]/.test(rel)&&rel.split('/').every(x=>x&&x!=='.'&&x!=='..'),'Ongeldig relatief installatiepad: '+rel);
  let cursor=fs.realpathSync(root);
  for(const part of rel.split('/')){cursor=path.join(cursor,part);try{fail(!fs.lstatSync(cursor).isSymbolicLink(),'Installatiepad bevat symlink: '+rel);}catch(e){if(e.code!=='ENOENT')throw e;}}
  return cursor;
}
const read=(r,p)=>{const f=safe(r,p);return fs.existsSync(f)?fs.readFileSync(f):null;};
const currentHash=(r,p)=>{const b=read(r,p);return b===null?null:hash(b);};
function managedHook(h){return h.type==='command'&&h.command==='node'&&Array.isArray(h.args)&&h.args[0]==='${CLAUDE_PROJECT_DIR}/.claude/aae/runtime/hook.mjs';}
function legacyHook(h){return h.type==='command'&&h.command==='node'&&Array.isArray(h.args)&&h.args[0]==='${CLAUDE_PROJECT_DIR}/.claude/gate/gate.mjs';}
export function hookConfig() {
  const command={type:'command',command:'node',args:['${CLAUDE_PROJECT_DIR}/.claude/aae/runtime/hook.mjs'],timeout:10};
  const events=['SessionStart','UserPromptSubmit','PreToolUse','PostToolUse','PostToolUseFailure','SubagentStart','SubagentStop','SessionEnd'];
  return Object.fromEntries(events.map(ev=>[ev,[{...(['PreToolUse','PostToolUse','PostToolUseFailure'].includes(ev)?{matcher:'*'}:{}),hooks:[{...command}]}]]));
}
export function mergeSettings(raw,{addHooks=true,legacyOkay=false}={}) {
  const cfg=raw?JSON.parse(raw.toString('utf8')):{};
  fail(cfg&&typeof cfg==='object'&&!Array.isArray(cfg),'Settings moeten een JSON-object zijn.');
  fail(cfg.disableAllHooks!==true,'Hooks zijn uitgeschakeld. Niet automatisch overrulen; bespreek die instelling.');
  fail(cfg.permissions?.defaultMode!=='bypassPermissions','bypassPermissions is niet geschikt voor deze omgeving.');
  const hooks={...cfg.hooks};
  for(const [event,groups]of Object.entries(hooks)) {
    fail(Array.isArray(groups),'Ongeldige hookgroep: '+event);
    hooks[event]=groups.map(g=>({...g,hooks:(g.hooks||[]).filter(h=>!managedHook(h)&&!(legacyOkay&&legacyHook(h)))})).filter(g=>g.hooks.length);
    if(!hooks[event].length)delete hooks[event];
  }
  if(addHooks)for(const [event,groups]of Object.entries(hookConfig()))hooks[event]=[...(hooks[event]||[]),...groups];
  cfg.hooks=hooks;
  return Buffer.from(JSON.stringify(cfg,null,2)+'\n');
}
export function planInstall(packageRoot,projectRoot,{resolvedClaude=null}={}) {
  fail(fs.existsSync(projectRoot)&&fs.statSync(projectRoot).isDirectory(),'Projectmap bestaat niet.');
  const root=fs.realpathSync(projectRoot), source=path.join(packageRoot,'payload');
  fail(!root.startsWith(fs.realpathSync(packageRoot)+path.sep)&&root!==fs.realpathSync(packageRoot),'Installeer niet in de uitgepakte pakketmap zelf.');
  const release=JSON.parse(fs.readFileSync(path.join(packageRoot,'PACKAGE.json'),'utf8'));
  const legacy=JSON.parse(fs.readFileSync(path.join(packageRoot,'tools/legacy-manifest.json'),'utf8'));
  const priorRaw=read(root,'.claude/aae/managed.json');
  const prior=priorRaw?JSON.parse(priorRaw):{files:{}};
  const operations=[],conflicts=[],warnings=[];
  const statusRaw=read(root,'.claude/aae/state/local.json');
  if(statusRaw){const s=JSON.parse(statusRaw);const live=[...Object.values(s.task?.calls||{}),...Object.values(s.request?.bootstrap_calls||{}),...Object.values(s.task?.external_calls||{}),...Object.values(s.request?.external_calls||{})].some(c=>['reserved','running','unknown'].includes(c.status));if(live||s.task?.command_running)conflicts.push('Er zijn nog actieve/onzekere AAE-processen of externe toolcalls. Eerst stoppen en gecontroleerd herstellen.');}
  const add=(p,bytes,reason)=>{
    const before=read(root,p);if((before===null&&bytes===null)||(before&&bytes&&before.equals(bytes)))return;
    operations.push({path:p,action:bytes===null?'retire':before?'replace':'create',reason,before_hash:before?hash(before):null,after_hash:bytes?hash(bytes):null,bytes});
  };
  let legacyOkay=true;
  for(const [p,hashes]of Object.entries(legacy.files)) {
    if(p==='CLAUDE.md'||p==='.claude/settings.json'||!p.startsWith('.claude/'))continue;
    const b=read(root,p);if(!b)continue;
    if(hashes.includes(hash(b)))add(p,null,'Exact herkend oud agentsysteembestand; bewaren in herstelkopie.');
    else {conflicts.push('Aangepast oud systeembestand: '+p+'. Eerst vergelijken, niet weggooien.');legacyOkay=false;}
  }
  for(const [p,expected]of Object.entries(release.files)) {
    const b=read(source,p);fail(b&&hash(b)===expected,'Pakketintegriteit mislukt: '+p);
    const existing=read(root,p);
    if(existing&&hash(existing)!==expected&&prior.files[p]!==hash(existing))conflicts.push('Niet-herkende lokale wijziging in beheerd pad: '+p);
    add(p,b,'AAE '+release.version+' beheerd bestand');
  }
  // Shared files are merged, not replaced as owned payload.
  const oldClaude=read(root,'CLAUDE.md');let c=oldClaude?.toString('utf8')||'# Projectinstructies\n';
  if(resolvedClaude)c=fs.readFileSync(resolvedClaude,'utf8');
  else if(oldClaude&&legacy.files['CLAUDE.md']?.includes(hash(oldClaude)))c='# Projectinstructies\n\nHet oude generieke agentsysteem is gearchiveerd door de AAE-installer.\n';
  else if(/werkwijze-subagents|docs\/ROUTE_PLAN\.md|\/design-go|Adaptieve werkwijze/.test(c))conflicts.push('CLAUDE.md bevat oude agentaansturing naast mogelijk eigen projectafspraken. Lever een zorgvuldig samengevoegde kopie via --resolved-claude.');
  c=c.replace(/<!-- AAE V3 MANAGED START -->[\s\S]*?<!-- AAE V3 MANAGED END -->/g,'').trimEnd();
  add('CLAUDE.md',Buffer.from(c+'\n\n'+BLOCK+'\n'),'Behoud projectafspraken; voeg een gemarkeerde AAE-import toe.');
  const local=read(root,'.claude/settings.local.json');
  if(local) {try{add('.claude/settings.local.json',mergeSettings(local,{addHooks:false,legacyOkay}),'Behoud lokale settings; verwijder alleen exact herkende oude/eigen hookhandlers.');}catch(e){conflicts.push(e.message);}}
  try{add('.claude/settings.json',mergeSettings(read(root,'.claude/settings.json'),{legacyOkay}),'Samenvoegen hooks; bestaande permissies en andere hooks blijven staan.');}catch(e){conflicts.push(e.message);}
  let ig=read(root,'.gitignore')?.toString('utf8')||'';
  ig=ig.replace(/# AAE V3 LOCAL START[\s\S]*?# AAE V3 LOCAL END/g,'').trimEnd();
  add('.gitignore',Buffer.from((ig?ig+'\n\n':'')+IGNORE+'\n'),'Voeg alleen lokale AAE-administratie aan ignore toe.');
  if(!read(root,'docs/aae/PROJECT_PROFILE.md'))add('docs/aae/PROJECT_PROFILE.md',Buffer.from('# Projectprofiel\n\nNog niet ingevuld. De hoofdsessie vat alleen bekende feiten kort samen bij de eerste concrete opdracht.\nGeen automatische repositoryscan. Bestaande docs/PROJECT_PROFILE.md mag als bron worden hergebruikt.\n'),'Nieuw compact profiel; geen bestaande projectdocumenten overschrijven.');
  if(!read(root,'docs/aae/PROGRESS.md'))add('docs/aae/PROGRESS.md',Buffer.from('# Voortgang\n\nAAE v3.1 geinstalleerd. Nog geen appwerk gestart. Leg hier alleen besluiten, blockers en de eerstvolgende stap vast.\n'),'Compact voortgangspunt.');
  add('.claude/aae/managed.json',Buffer.from(JSON.stringify({version:release.version,files:release.files},null,2)+'\n'),'Installatie-inventaris voor integriteitscontrole en veilige updates.');
  if(read(root,'scripts/visual-check.mjs'))warnings.push('Bestaand scripts/visual-check.mjs blijft behouden; v3.1 gebruikt het niet automatisch.');
  warnings.push('Controleer na herstart /hooks en /agents. Global, managed en plugininstructies worden niet door deze installer gewist.');
  warnings.push('Geen live Claude Code- of abonnementsmeting uitgevoerd door de installer.');
  return {version:release.version,project:root,operations,conflicts,warnings};
}
function writeFile(root,p,bytes,mode=0o644) {
  const target=safe(root,p);fs.mkdirSync(path.dirname(target),{recursive:true,mode:0o700});
  if(bytes===null){fs.rmSync(target,{force:true});return;}
  const tmp=target+'.aae-'+crypto.randomUUID();fs.writeFileSync(tmp,bytes,{mode,flag:'wx'});fs.renameSync(tmp,target);
}
export function publicPlan(plan){return {...plan,operations:plan.operations.map(({bytes,...op})=>op)};}
export function applyInstall(plan) {
  fail(plan.conflicts.length===0,'Installatie gestopt wegens conflicten. Geen projectwijzigingen gedaan.');
  if(!plan.operations.length)return {status:'UNCHANGED',backup:null};
  const root=plan.project,backupRel='.aae-backups/'+new Date().toISOString().replace(/[:.]/g,'-')+'-'+crypto.randomUUID().slice(0,8),backup=safe(root,backupRel);
  fs.mkdirSync(backup,{recursive:true,mode:0o700});const entries=[];
  // Record originals before any project edits. Abort on changes since dry run.
  for(const [i,op]of plan.operations.entries()) {
    fail(currentHash(root,op.path)===op.before_hash,'Bestand veranderde sinds plan: '+op.path);
    const b=read(root,op.path),file=i+'.bin';
    const mode=b?fs.statSync(safe(root,op.path)).mode&0o777:0o644;
    if(b)fs.writeFileSync(path.join(backup,file),b,{mode:0o600});
    entries.push({path:op.path,before_hash:op.before_hash,after_hash:op.after_hash,blob:b?file:null,mode});
  }
  const manifest={schema_version:3,project:root,version:plan.version,entries};
  fs.writeFileSync(path.join(backup,'RESTORE.json'),JSON.stringify(manifest,null,2)+'\n',{mode:0o600});
  const done=[];
  try {
    // Config activation last; payload and agent definitions first.
    const ordered=[...plan.operations].sort((a,b)=>Number(a.path.includes('settings'))-Number(b.path.includes('settings')));
    for(const op of ordered) {fail(currentHash(root,op.path)===op.before_hash,'Gelijktijdige wijziging: '+op.path);writeFile(root,op.path,op.bytes);done.push(op.path);}
    return {status:'INSTALLED',version:plan.version,changed:done.length,backup:backupRel,rollback_command:'node install.mjs --project '+JSON.stringify(root)+' --rollback '+backupRel};
  } catch(e) {
    for(const p of done.reverse()){const ent=entries.find(x=>x.path===p);writeFile(root,p,ent.blob?fs.readFileSync(path.join(backup,ent.blob)):null,ent.mode);}
    throw new Error('Installatie teruggedraaid na fout: '+e.message);
  }
}
export function rollback(projectRoot,backupRel,{apply=false}={}) {
  const root=fs.realpathSync(projectRoot),backup=safe(root,backupRel);
  fail(backupRel.startsWith('.aae-backups/'),'Kies een AAE-herstelkopie in dit project.');
  const manifest=JSON.parse(fs.readFileSync(path.join(backup,'RESTORE.json'),'utf8'));
  fail(manifest.project===root,'Herstelkopie hoort bij ander project.');
  const conflicts=[];
  for(const e of manifest.entries) {if(currentHash(root,e.path)!==e.after_hash)conflicts.push('Na installatie gewijzigd: '+e.path);if(e.blob){fail(/^[0-9]+\.bin$/.test(e.blob),'Ongeldige backupnaam.');fail(hash(fs.readFileSync(path.join(backup,e.blob)))===e.before_hash,'Herstelkopie beschadigd: '+e.path);}}
  if(!apply)return {status:'ROLLBACK_PLAN',conflicts,files:manifest.entries.map(e=>e.path)};
  fail(conflicts.length===0,'Terugdraaien gestopt: '+conflicts.join('; '));
  for(const e of [...manifest.entries].reverse())writeFile(root,e.path,e.blob?fs.readFileSync(path.join(backup,e.blob)):null,e.mode);
  return {status:'ROLLED_BACK',restored:manifest.entries.length,note:'Lokale nieuwe state/logs blijven als bewijs staan; applicatiebestanden zijn niet geraakt.'};
}
