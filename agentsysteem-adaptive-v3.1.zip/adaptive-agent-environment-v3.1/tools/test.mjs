import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import {spawnSync} from 'node:child_process';
const root=fileURLToPath(new URL('../',import.meta.url));
const files=['payload/.claude/aae/tests','tests'].flatMap(d=>fs.readdirSync(path.join(root,d)).filter(f=>f.endsWith('.test.mjs')).sort().map(f=>path.join(root,d,f)));
const result=spawnSync(process.execPath,['--test',...files],{cwd:root,stdio:'inherit',shell:false});process.exitCode=result.status??1;
