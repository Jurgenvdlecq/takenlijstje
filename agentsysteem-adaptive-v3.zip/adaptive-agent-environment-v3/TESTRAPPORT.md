# Testrapport - Adaptive Agent Environment v3.0.0

Datum: 29 september 2026. Uitgevoerd op tijdelijke lokale projecten met Linux en Node v22.16.0. Het bestaande Takenlijstje-project, een productieomgeving en het originele ZIP-bestand zijn niet gewijzigd.

## Resultaat

**113 geautomatiseerde tests uitgevoerd: 113 geslaagd, 0 mislukt, 0 overgeslagen.** De laatste volledige run duurde ongeveer 1,9 seconde in deze omgeving. Dit is een lokale testduur, geen schatting van Claude-modelverbruik of van jouw computer.

| Onderdeel | Tests | Belangrijkste dekking |
|---|---:|---|
| Poort, schema en route | 50 | Lege templates, analyse-only, agents buiten route, budgetten, GO-binding, pauze, shellomwegen, symlinks, bronwijzigingen, ongeldige state |
| Lifecycle en gelijktijdigheid | 7 | Late async-events, hervatten, handback, onbekende agent, werkelijk twee gelijktijdige hookprocessen, privé testauth, juiste labeling van usage |
| Commandrunner en bewijs | 26 | Nieuwe commandtoestemming, fingerprints, max_runs, letterlijke argv, timeout, ontbrekende executable, begrensde uitvoer, failretry, bewijsgeldigheid, High Assurance |
| Visuele helper | 5 | Config, credentials/remotegrens, private storageState, ontbrekende markers, geen automatische browserinstallatie |
| Installatie en herstel | 20 | Dryrun, behoud appdata/projectregels, herhaalde installatie, v2-herkenning, aangepaste bestanden, symlinks, backups, rollbackconflicten, doctor, echte installer-CLI |
| Bestands-/configcontrole | 5 | Alle 13 rollen, Node-syntaxis, voorbeelden, bewust ongeldig template, UTF-8, payloadhashes en documentverwijzingen |

Reproduceren vanuit de uitgepakte pakketmap:

```sh
node tools/test.mjs
```

Dit start geen Claude-agent, API, netwerkverbinding of browser. Tests werken uitsluitend in tijdelijke fixtures; de fixturehelper kopieert alleen de benodigde AAE-runtime/docs, nooit de complete applicatierepository, cookies, node_modules of lokale state. `doctor` kan `claude --version` proberen; dat is geen modelaanroep.

## Aanvullende migratieproef met het complete originele v2-pakket

Ook buiten de testsuite is de volledige eerder aangeleverde v2-omgeving in een wegwerpproject geinstalleerd, daarna met v3 bijgewerkt en teruggedraaid.

- v3-installatie geslaagd; 75 bestandsbewerkingen, waaronder het archiveren van 33 exact herkende oude systeemfiles.
- De oude gate en supervisor waren niet meer actief op hun oude pad.
- De 13 nieuwe aae-rollen waren aanwezig; beheerde bestandshashes klopten.
- Het toegevoegde appcode-controlebestand bleef byte-voor-byte gelijk.
- Rollback geslaagd; de oude gate werd teruggezet.
- `doctor` rapporteerde dat Claude Code niet in deze omgeving is aangetroffen.

Bewijs staat in `evidence/full-v2-migration.json`; de volledige laatste testuitvoer in `evidence/node-tests.tap`.

## Wat is nadrukkelijk niet getest?

**Een echte Claude Code-sessie: NOT_RUN.** Geen CLI aanwezig voor live model-/agentuitvoering. De tests gebruiken echte Node-processen en gesimuleerde hook-eventgegevens, niet het werkelijk geladen Anthropic-hostproces.

**Werkelijke browserflow: NOT_RUN.** Configvalidatie en foutafhandeling zijn getest; er is hier geen Playwright/Chromium-appsessie gestart. Ingelogde screenshots hangen van projectfixtures en de host af.

**Windows, macOS en Claude cloud-host: NOT_RUN.** Lokale tests zijn op Linux uitgevoerd. Native Windows uitvoerbare bestanden, shellgedrag en cloudpermissions moeten gericht worden nagegaan; er is geen automatische shellfallback ingebouwd.

**Abonnementsbesparing/Max-tegoed: NIET GEMETEN.** Aanroeplimieten en compacte overdrachten zijn geimplementeerd. Dit is geen bewijs voor een bepaald besparingspercentage of een garantie dat een sessielimiet niet wordt bereikt.

**Volledige beveiligingssandbox: NIET GELEVERD.** Projectcommands draaien na goedkeuring met jouw OS-rechten. De runtime bewaakt de ondersteunde workflow, maar inspecteert niet alle transitive effecten van goedgekeurde code. Natuurlijke-taalclassificatie en bewijsinhoud blijven model-/mensenoordeel. Native hostrechten blijven aanvullend gelden.

## Vrijgaveadvies

Het pakket is lokaal getest en gereed voor een gecontroleerde installatieproef. Voer eerst `.claude/aae/docs/LIVE_CHECK.md` uit in een wegwerpkopie op jouw werkelijke host. Bevestig dat hooks actief zijn, rollen correct laden, een ongeldige actie daadwerkelijk geweigerd wordt en een normale kleine taak wel uitvoerbaar blijft. Pas daarna in je dagelijkse appwerk gebruiken.

Het aantal groene tests is niet de maat voor absolute kwaliteit. De negatieve controles op de auditbevindingen, expliciete beperkingen en de nog vereiste hosttest zijn minstens zo belangrijk.
