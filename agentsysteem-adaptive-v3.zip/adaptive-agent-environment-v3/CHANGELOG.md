# 3.0.0 - 2026-09-29
- Vervangt markdownbeslissingen en oude niveauvrijgave door gevalideerde taakcontracten.
- Voegt taskgebonden GO/pauze, agentbudget, dispatchregistratie en bounded commandrunner toe.
- Scherpt 13 rollen aan; alle specialistische uitvoer read-only, model/maxTurns expliciet.
- Scheidt analyse, implementatie, beoordeling en deployment; geen automatische publicatie.
- Voeg veilige dry-run-installer, gecontroleerde v1/v2-retirement, backup/rollback en doctor toe.
- Voegt onafhankelijke/actuele bewijsvoorwaarden, gerichte visuele fixturehelper en live-check toe.
- Houdt OS-sandbox, hostcompatibiliteit en abonnementsmeting expliciet buiten onbewezen claims.

Zie TESTRAPPORT.md voor daadwerkelijk uitgevoerde controles. Geen live app-/Claude-/Max-meting in deze build.
